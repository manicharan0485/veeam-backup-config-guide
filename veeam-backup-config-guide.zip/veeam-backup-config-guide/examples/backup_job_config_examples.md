# Backup Job Configuration Examples

Real-world Veeam backup job configurations for common enterprise scenarios.

---

## Example 1 — Production SQL Server (Critical Tier)

```
Job Name:         PROD-SQL-Daily
Job Type:         Backup (VMware vSphere)
VMs:              prod-sql-01, prod-sql-02

Storage:
  Repository:     SOBR-Production (Scale-out)
  Restore points: 14 (simple)
  GFS:
    Weekly:       8 weeks
    Monthly:      12 months
    Yearly:       1 year

Schedule:
  Daily:          22:30 (Mon–Sat)
  Active Full:    Sunday 22:00

Guest Processing:
  ☑ Application-aware processing: Enabled
  ☑ Transaction log handling: Process with job (truncate)
  ☑ Guest credentials: svc_veeam_backup (local admin)

Advanced:
  ☑ Inline deduplication: Enabled
  ☑ Compression: Optimal
  ☑ Encryption: Enabled
  Notification: Email on failure → ops@company.com

Expected backup window: 22:30–01:30 (3 hours)
RPO: 24 hours | RTO target: 2 hours
```

---

## Example 2 — File Server (Standard Tier)

```
Job Name:         STD-FileServer-Daily
Job Type:         Backup (VMware vSphere)
VMs:              fs-01, fs-02, fs-03

Storage:
  Repository:     LocalRepo-Primary
  Restore points: 7 (simple)
  GFS:
    Weekly:       4 weeks
    Monthly:      6 months

Schedule:
  Daily:          23:00 (Mon–Sat)
  Synthetic Full: Saturday 23:00

Guest Processing:
  ☑ Application-aware processing: Enabled
  ☑ Guest file system indexing: Enabled (for file-level search)

Advanced:
  ☑ Compression: Optimal
  ☑ Encryption: Disabled (internal network, encrypted at rest)

RPO: 24 hours | RTO target: 4 hours
```

---

## Example 3 — Backup Copy to AWS S3 (Offsite DR)

```
Job Name:         COPY-S3-Offsite
Job Type:         Backup Copy

Source:
  Backups:        PROD-SQL-Daily, STD-FileServer-Daily

Target:
  Repository:     SOBR-S3-Offsite (AWS S3 Standard)
  Restore points: 30 (simple)
  GFS:
    Weekly:       12 weeks
    Monthly:      12 months
    Yearly:       3 years

Schedule:
  Mode:           Immediate copy (as soon as primary job completes)

Advanced:
  ☑ Encryption: Enabled (mandatory for offsite)
  ☑ Compression: Optimal

Notes:
  - S3 bucket: veeam-backup-offsite-prod (private, versioning enabled)
  - AWS region: eu-west-1 (different from primary eu-central-1)
  - Lifecycle: S3 Standard → S3-IA after 30d → Glacier after 90d
```

---

## Example 4 — Linux VMs with PostgreSQL

```
Job Name:         PROD-Linux-Postgres
Job Type:         Backup (VMware vSphere)
VMs:              prod-pg-01, prod-pg-02

Storage:
  Repository:     LocalRepo-Primary
  Restore points: 14

Schedule:
  Daily:          22:00

Guest Processing:
  ☑ Application-aware processing: Enabled
  Pre-freeze script:  /opt/veeam/scripts/pre-freeze.sh
  Post-thaw script:   /opt/veeam/scripts/post-thaw.sh
  Linux credentials:  veeam_svc (sudo, no password for pg_* commands)

Notes:
  - Veeam agent for Linux deployed on each VM
  - Scripts flush PostgreSQL WAL and start pg_basebackup mode
  - Restore tested monthly via restore_test_automation.sh
```

---

## Example 5 — Veeam Agent for Linux (Physical/Cloud VM)

```
# Deploy Veeam Agent via Veeam Backup & Replication console
# or manually:

# Ubuntu/Debian
wget https://download.veeam.com/veeam-release-deb_1.0_amd64.deb
dpkg -i veeam-release-deb_1.0_amd64.deb
apt-get update
apt-get install veeam

# Configure backup job
veeamconfig job create --name "aws-ec2-backup" \
  --mode managed \
  --repoName "VeeamRepo" \
  --backupallsystem \
  --compressionlevel 5

# Start job manually
veeamconfig job start --name "aws-ec2-backup"

# Check job status
veeamconfig session list
veeamconfig session log --id <session-id>
```

---

## RTO/RPO Summary Table

| Job | Tier | RPO | RTO | Retention |
|-----|------|-----|-----|-----------|
| PROD-SQL-Daily | Critical | 24h | 2h | 14d / 8w / 12m / 1y |
| STD-FileServer-Daily | Standard | 24h | 4h | 7d / 4w / 6m |
| COPY-S3-Offsite | DR Copy | 24h | 4h | 30d / 12w / 12m / 3y |
| PROD-Linux-Postgres | Critical | 24h | 2h | 14d / 8w / 12m |
