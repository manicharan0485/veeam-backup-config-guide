# Application-Aware Backup in Veeam

## What is Application-Aware Processing?

Application-aware processing (AAP) ensures that backups of running databases and applications are crash-consistent or application-consistent — meaning the data can be restored to a clean, usable state without manual recovery steps.

Veeam achieves this using **Microsoft VSS (Volume Shadow Copy Service)** on Windows and **pre/post freeze scripts** on Linux.

---

## Supported Applications

| Application | VSS Writer | Transaction Log Truncation |
|-------------|-----------|---------------------------|
| Microsoft SQL Server | ✅ | ✅ (optional) |
| Microsoft Exchange | ✅ | ✅ |
| Active Directory | ✅ | N/A |
| SharePoint | ✅ | N/A |
| Oracle (Windows) | ✅ | Manual script |
| MySQL / PostgreSQL (Linux) | Pre/post scripts | Manual script |

---

## Enabling Application-Aware Processing

```
Job → Edit → Guest Processing tab

☑ Enable application-aware processing
  → Applications → Add/Edit
    → Select VM
    → Transaction log handling:
       ○ Process transaction logs with this job (truncate after backup)
       ○ Perform copy only (no truncation — if another tool manages logs)
       ○ Do not truncate logs

☑ Enable guest file system indexing (optional — enables file-level search)

Guest OS credentials:
  → Add Windows/Linux credentials with local admin rights
```

---

## SQL Server Specific Settings

### Log Truncation Options

| Option | When to Use |
|--------|------------|
| **Truncate logs** | Veeam is the only backup tool; no SQL Agent jobs |
| **Copy only** | SQL Agent or another tool handles log backups |
| **Don't truncate** | Compliance requirement to keep all logs |

> ⚠️ **Important:** If you truncate logs via Veeam AND SQL Agent, logs may be truncated before SQL Agent can back them up — causing gaps in point-in-time recovery.

### Verifying VSS Writer Status (on SQL VM)

```powershell
# Run on the SQL Server VM
vssadmin list writers

# Healthy output should show:
# Writer name: 'SqlServerWriter'
# State: [1] Stable
# Last error: No error
```

### Fixing Failed VSS Writers

```powershell
# Restart VSS-related services
net stop VSS
net stop VDS
net start VDS
net start VSS

# If SQL writer still fails:
net stop MSSQLSERVER
net start MSSQLSERVER
```

---

## Linux VMs — Pre/Post Freeze Scripts

For Linux VMs (MySQL, PostgreSQL), use pre/post scripts to quiesce the database before snapshot.

### PostgreSQL Example

```bash
# /opt/veeam/scripts/pre-freeze.sh
#!/bin/bash
# Flush and lock PostgreSQL tables before snapshot
psql -U postgres -c "SELECT pg_start_backup('veeam_snapshot', true);"
```

```bash
# /opt/veeam/scripts/post-thaw.sh
#!/bin/bash
# Release backup lock after snapshot
psql -U postgres -c "SELECT pg_stop_backup();"
```

```
Job → Guest Processing → Pre/Post Scripts
  Pre-freeze script:  /opt/veeam/scripts/pre-freeze.sh
  Post-thaw script:   /opt/veeam/scripts/post-thaw.sh
```

---

## Restore Types for Applications

### SQL Server — Item-Level Restore (single database)

```
Backups → Right-click backup → Restore application items
→ Microsoft SQL Server databases
→ Select restore point
→ Select database → Restore to original location
   OR → Export to .bak file
```

### SQL Server — Point-in-Time Restore

```
Only available if:
  ✅ Application-aware processing enabled
  ✅ Log truncation set to "Process transaction logs with this job"
  ✅ Log backup chain is unbroken

Steps:
  Restore application items → SQL Server
  → Select database → Point-in-time restore
  → Set target date/time
  → Restore
```

### Active Directory — Object-Level Restore

```
Restore application items → Microsoft Active Directory objects
→ Browse to deleted/modified object
→ Restore to original location (authoritative restore)
```

---

## Verification — SureBackup

SureBackup automatically tests recoverability of backups by booting VMs in an isolated network and running verification scripts.

```
Configuration:
  New SureBackup Job
  → Application Group: select critical VMs to test
  → Virtual Lab: isolated network sandbox
  → Schedule: weekly (run after full backup)
  → Verification tests:
     ☑ Heartbeat test (VM boots successfully)
     ☑ Ping test (network connectivity)
     ☑ Application test (SQL/Exchange service running)
```

> SureBackup provides proof that backups are actually restorable — ideal for compliance audits and management reporting.
