# Veeam Job Configuration Best Practices

## 1. Backup Job Types

### Full Backup
- **When:** Weekly (Sunday night recommended)
- **Use case:** Baseline for all incremental chains
- **Storage:** Largest — plan for 1.2–1.5x raw data size

### Incremental Backup
- **When:** Daily (Mon–Sat)
- **Use case:** Backs up only changed blocks since last backup
- **Dependency:** Requires a healthy full backup as anchor

### Reverse Incremental
- **When:** Environments needing always-ready full restore point
- **Use case:** Latest restore point is always a full backup
- **Trade-off:** Higher I/O during backup window

---

## 2. Proxy Server Sizing

The backup proxy is the workhorse of Veeam — size it correctly.

| Environment | VMs | Recommended Proxy vCPUs | RAM |
|-------------|-----|------------------------|-----|
| Small | < 20 | 4 vCPU | 8 GB |
| Medium | 20–100 | 8 vCPU | 16 GB |
| Large | 100+ | 16+ vCPU | 32 GB |

**Best practices:**
- Deploy at least 2 proxy servers for redundancy
- Place proxies close to the data source (same host or network segment)
- Use dedicated proxies for production — never the Veeam server itself
- Enable parallel task processing: set max concurrent tasks to `(vCPUs / 2)`

---

## 3. Repository Configuration

### Local Repository
```
Recommended path:     D:\VeeamBackup\  (separate disk from OS)
Block size:           1 MB (default — good for most workloads)
Decompress before:    Enabled (for dedup appliances)
Align backup files:   Enabled
```

### Scale-Out Backup Repository (SOBR) with AWS S3
```
Tier 1 (Performance): Local disk or NAS  — fast restore access
Tier 2 (Capacity):    AWS S3 Standard    — cost-effective long-term
Tier 3 (Archive):     AWS S3 Glacier     — compliance/long retention

Move to capacity tier after: 7 days
Move to archive tier after:  90 days
```

---

## 4. Scheduling Best Practices

- **Backup window:** 22:00–06:00 (avoid business hours)
- **Stagger job start times** by 15–30 minutes to avoid proxy overload
- **Synthetic full:** Saturday 23:00 (avoids full re-read from source)
- **Active full:** Monthly (1st Sunday) — ensures clean recovery chain
- **Backup copy job:** Offset by 2 hours after primary job completes

```
Example schedule:
22:00  — VM Group A (incremental, Mon–Fri)
22:15  — VM Group B (incremental, Mon–Fri)
22:30  — Database VMs (application-aware, daily)
01:00  — Backup copy to AWS S3 (daily)
23:00  — Synthetic full (Saturday)
```

---

## 5. Encryption

Always encrypt backup files, especially for offsite/cloud copies.

```
Settings > Backup Infrastructure > Backup Repositories
→ Select repository → Edit
→ Storage tab → Enable backup file encryption
→ Key: Use password managed in Veeam Enterprise Manager
```

**Important:** Store encryption passwords in a password manager AND documented offline. Lost keys = unrecoverable backups.

---

## 6. Instant VM Recovery

Use when RTO is critical — boots a VM directly from the backup file.

```
Right-click backup → Instant Recovery → VMware/Hyper-V VM
→ Select restore point
→ Choose target host and datastore
→ VM boots in ~2 minutes (reads from backup, writes to target)
→ Migrate to production storage when ready (Storage vMotion)
```

**RTO with Instant Recovery:** ~2–5 minutes  
**RTO with full restore:** 30–120 minutes (depends on VM size)

---

## 7. Common Errors & Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| `Failed to create snapshot` | VSS writer issue | Check VSS writers: `vssadmin list writers` |
| `Repository out of space` | Storage full | Extend storage or reduce retention |
| `Transport error` | Network or service issue | Restart Veeam Transport Service on proxy |
| `Processing timeout` | Slow storage or large VM | Increase job timeout, split VM into separate job |
| `Application-aware processing failed` | Credentials issue | Verify guest OS credentials in job settings |
