# Veeam Retention Policies

## GFS — Grandfather-Father-Son Retention

The standard retention model for enterprise backup environments.

```
Daily (Son):     Keep last 14 days of daily restore points
Weekly (Father): Keep last 4 weekly full backups (Sunday)
Monthly (GF):    Keep last 12 monthly full backups (1st Sunday)
Yearly (GGF):    Keep last 1–3 yearly backups (January)
```

---

## Retention by Workload Tier

| Tier | Workload Examples | Daily | Weekly | Monthly | Yearly |
|------|------------------|-------|--------|---------|--------|
| **Critical** | Production DB, ERP, AD | 14 days | 8 weeks | 12 months | 3 years |
| **Standard** | App servers, file servers | 7 days | 4 weeks | 6 months | 1 year |
| **Development** | Dev/test VMs | 3 days | 2 weeks | None | None |

---

## RPO vs Retention (Different Concepts)

| Concept | Definition | Example |
|---------|-----------|---------|
| **RPO** | Max acceptable data loss | "We can lose max 1 hour of data" |
| **Retention** | How long backup history is kept | "We keep 30 days of restore points" |

RPO drives backup **frequency**.  
Retention drives backup **storage sizing**.

---

## Storage Sizing Formula

```
Daily storage needed = (VM size × change rate) × number of VMs

Example:
- 20 VMs × 100 GB average = 2 TB total
- 5% daily change rate = 100 GB/day incremental
- Full backup: 2 TB × 0.5 (compression) = 1 TB
- 14 daily incrementals: 100 GB × 14 × 0.5 = 700 GB
- 4 weekly fulls: 1 TB × 4 = 4 TB
- Total estimated: ~6 TB
```

---

## Configuring GFS in Veeam

```
Job → Edit → Storage tab → Advanced (Backup)

Simple retention:
  ☑ Keep certain number of restore points: [14]

GFS (enable separately):
  ☑ Keep weekly full backups for: [4] weeks
  ☑ Keep monthly full backups for: [12] months
  ☑ Keep yearly full backups for: [1] years
```

---

## Backup Copy Job (Offsite / 3-2-1 Rule)

The 3-2-1 backup rule:
- **3** copies of data
- **2** different media types
- **1** offsite location

```
Primary backup:   Local repository (fast restore)
Backup copy:      AWS S3 or Azure Blob (offsite DR)
Archive:          AWS Glacier (long-term compliance)
```

Backup copy job settings:
```
Source:          Primary backup job
Target:          Scale-out repository (S3 tier)
Schedule:        Daily, 2 hours after primary job
Retention:       30 restore points
GFS:             Weekly × 12, Monthly × 12
Encrypt:         ✅ Always for offsite copies
```
